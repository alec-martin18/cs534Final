function computeHist

I1 = imread('1.jpg');
I2 = imread('2.jpg');
I3 = imread('3.jpg');
I4 = imread('4.jpg');

Y = {I1,I2,I3,I4};
h1 = imhist(rgb2gray(I1));
h2 = imhist(rgb2gray(I2));
h3 = imhist(rgb2gray(I3));
h4 = imhist(rgb2gray(I4));

X = [h1,h2,h3,h4];
for i = 1:4
    hisdiff(i) = sqrt(mean((X(:,i)).^2));    
end
[~,I] = max(hisdiff);
num1 = I;
if length(Y) - num1 == 0 
    num2 = num1 - 1;
else 
    num2 = num1 + 1;
end
figure
imshow(Y{num1});
z = imhistmatch(Y{num1}, Y{num2});
figure
imshow(z);

if num1 == 1
    n2 = 2; n3 = 3; n4 = 4;
elseif num1 == 2
    n2 = 1; n3 = 3; n4 = 4;
elseif num1 == 3
    n2 = 1; n3 = 2; n4 = 4;
elseif num1 == 4
    n2 = 1; n3 = 2; n4 = 3;  
end
path=cd;
destination = [path,'/input_images'];
fullFileName1 = fullfile(destination,[num2str(num1),'.jpg']);
imwrite(z, fullFileName1);
fullFileName2 = fullfile(destination, [num2str(n2),'.jpg']);
imwrite(Y{n2}, fullFileName2);
fullFileName3 = fullfile(destination, [num2str(n3),'.jpg']);
imwrite(Y{n3}, fullFileName3);
fullFileName4 = fullfile(destination, [num2str(n4),'.jpg']);
imwrite(Y{n4}, fullFileName4);
end
